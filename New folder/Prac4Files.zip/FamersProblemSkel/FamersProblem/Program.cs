﻿using System;
using cs2;

namespace FamersProblem
{
    class Program
    {
        /// <summary>
        /// Solution to the Farmer's Problem using a Queue.
        /// </summary>
        private static void QueueSolution ()
        {
            //  TODO...
        } // QueueSolution

        /// <summary>
        /// Solution to the Farmer's Problem using a Stack.
        /// </summary>
        private static void StackSolution ( )
        {
            // TODO...
        } // StackSolution

        static void Main (string[] args)
        {
            Console.WriteLine("Queue Solution:");
            QueueSolution();

            Console.WriteLine("\nStack Solution:");
            StackSolution();
        } // Main
    } // class Program
}
