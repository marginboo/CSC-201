// Program using a queue to perform a breadth-first maze search.
// George Wells  --  19 September 2013

using cs2;
using System;
using System.IO;

public class QSearch
  { private const int MAX_COORD = 10; // Size of maze

    private struct Position  // Coordinates of location in maze
      { public int r, // Row coordinate
                   c, // Column coordinate
                   len;
      } // inner struct Position

    private IQueue<Position> posQueue = new ListQueue<Position>(); // Queue of positions still to be checked

    private IStack<Position> posStack = new ListStack<Position>();

    private bool[,] maze = new bool[MAX_COORD, MAX_COORD]; // Description of maze

    private bool[,] beenThere = new bool[MAX_COORD, MAX_COORD]; // Keep track of previous positions

    private void readMaze (String mazeFile)
      // Read in the maze
      { int r, c; // Loop counters
        TextReader f = File.OpenText(mazeFile);

        for (r = 0; r < MAX_COORD; r++)
          { String line = f.ReadLine();
            for (c = 0; c < MAX_COORD; c++)
              { maze[r,c] = (line[c] == ' ');
              }
          }
        f.Close();
      } // readMaze

    private void addPosition(int row, int col, int length)
      // Put a new position on the queue of positions
      { Position p = new Position();
        p.r = row;
        p.c = col;
        p.len = length;
        //posQueue.Add(p);
        posStack.Push(p);

      } // addPosition

    public void SolveMaze ()
      { int r, c = 0; // Row and column coordinates;

        try
          { readMaze("../../../maze1.txt");
          }
        catch (IOException e)
          { Console.Error.WriteLine("Error reading data file");
            Console.Error.WriteLine(e.StackTrace);
            System.Environment.Exit(1);
          }

        // Initialise beenThere to all FALSE
        for (r = 0; r < MAX_COORD; r++)
          for (c = 0; c < MAX_COORD; c++)
            beenThere[r, c] = false;
        // Find starting position
        for (r = 0; r < MAX_COORD; r++)
          if (maze[r, 0]) // r is starting row
            break;
        // Put starting position on queue
        addPosition(r, 0,0);
        
        // Now do search
        int PosCounter = 0;
        int Lengthnum = 0;
        while (! /*posQueue*/posStack.IsEmpty())
          { Position nextPos;

            // Remove next position from queue and try all possible moves
            //nextPos = posQueue.Remove();
            nextPos = posStack.Pop();
            c = nextPos.c;
            r = nextPos.r;
            Lengthnum = nextPos.len;

            beenThere[r, c] = true; // Note that we have visited this spot
            Console.WriteLine("Visiting position: " + r + ", " + c);
            PosCounter++;
            if (c == MAX_COORD-1) // Found exit, so leave search loop
              break;

            // Try to move up
            if (maze[r-1, c] && ! beenThere[r-1, c])
              addPosition(r-1, c, nextPos.len +1);
            // Try to move right
            if (maze[r, c+1] && ! beenThere[r, c+1])
              addPosition(r, c+1, nextPos.len+1);
            // Try to move down
            if (maze[r+1, c] && ! beenThere[r+1, c])
              addPosition(r+1, c, nextPos.len+1);
            // Try to move left
            if (c > 0 && maze[r, c-1] && ! beenThere[r, c-1])
              addPosition(r, c-1, nextPos.len+1);
        }// while
       
        //while (!posStack.IsEmpty())
        //{
        //    posStack.Pop();
        //}
        if (c == MAX_COORD-1) // Found exit
          Console.WriteLine("Success!  Found exit at position: " + r + ", " + c + " in " + Lengthnum);
        else
          Console.WriteLine("Failed to find exit from maze.");
        Console.WriteLine(PosCounter + " Positions checked");
        
    } // solveMaze
     

    public static void Main (String[] args)
      { QSearch qs = new QSearch();
        qs.SolveMaze();
        Console.ReadLine();
      } // Main

  } // class QSearch
