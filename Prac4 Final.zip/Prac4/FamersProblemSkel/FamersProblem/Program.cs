﻿using System;
using cs2;

namespace FamersProblem
{
    class Program
    {
        /// <summary>
        /// Trying to solve Farmers problem using a queue and a stack
        /// Author: Alden Boby (using Problem state class developed by George Wells Version 1.0 (10 May 2015))
        /// </summary>
        
        static IQueue<ProblemState> stateQueue = new ListQueue<ProblemState>();//Creation of Queue
        static IStack<ProblemState> stateStack = new ListStack<ProblemState>();//Creation of Stack

        /// <summary>
        /// Solution to the Farmer's Problem using a Queue.
        /// </summary>
        private static void QueueSolution ()
        {
            int i = 0;//integer used to control inner while loop

            //GenericList that stores all the safe problem states found 
            GenericList<ProblemState> AllTrueStates = new GenericList<ProblemState>();
            //Initializes a new problem state [F:GLC][]
            ProblemState InitialState = new ProblemState();
            //Initialisation  of latest state which stores the newest safe state i.e it gets updated with the step closest to the solution
            ProblemState LatestState = InitialState;
            //StateCheck checks all possible moves of whatever problem state it it given
            GenericList<ProblemState> StateCheck = InitialState.GetMoves();
            AllTrueStates.Add(LatestState);
            stateQueue.Add(LatestState);//Make sure queue is not empty
            Console.WriteLine(InitialState.ToString() + " ---> Initial State");//Prints the initial/starting state
            while (!stateQueue.IsEmpty())
            {
                while (i < StateCheck.Length())
                {
                    if (AllTrueStates.Position(StateCheck.Get(i)) != -1)//returning -1 means the safe state has not been found
                    {
                        i++;
                        continue;
                    }
                    if (StateCheck.Get(i).IsSafe())//Add safe state to queue
                    {
                        stateQueue.Remove();
                        Console.WriteLine(StateCheck.Get(i).ToString());//Print State
                        stateQueue.Add(StateCheck.Get(i));//Add to Queue
                        LatestState = StateCheck.Get(i);
                        StateCheck = LatestState.GetMoves();
                        AllTrueStates.Add(LatestState);//Mark state as visited
                    }
                    else
                    {
                        stateQueue.Remove();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(StateCheck.Get(i) + " ---> unsafe");//print out unsafe state on console
                        stateQueue.Add(StateCheck.Get(i));
                        Console.ResetColor();
                    }
                    i++;
                }
                i = 0;
                if (LatestState.IsFinal())//Checks to see if the problem has been solved 
                {
                   Console.ForegroundColor = ConsoleColor.Green;
                   Console.WriteLine("Problem solved final state found: "+LatestState.ToString());
                   Console.ResetColor();
                   break;
                }
            }
            //  TODO...
        } // QueueSolution

        /// <summary>
        /// Solution to the Farmer's Problem using a Stack.
        /// </summary>
        private static void StackSolution ( )
        {
            int i = 0;//integer used to control inner while loop

            //GenericList that stores all the safe problem states found 
            GenericList<ProblemState> AllTrueStates = new GenericList<ProblemState>();
            //Initializes a new problem state [F:GLC][]
            GenericList<ProblemState> AllFalseStates = new GenericList<ProblemState>();
            ProblemState InitialState = new ProblemState();
            //Initialisation  of latest state which stores the newest safe state i.e it gets updated with the step closest to the solution
            ProblemState LatestState = InitialState;
            //StateCheck checks all possible moves of whatever problem state it it given
            GenericList<ProblemState> StateCheck = InitialState.GetMoves();
            stateStack.Push(LatestState);//Make sure stack is not empty
            AllTrueStates.Add(InitialState);
            Console.WriteLine(InitialState.ToString() + " ---> Initial State");//Prints the initial/starting state
            while (!stateStack.IsEmpty())
            {
                while (i < StateCheck.Length())
                {
                    if (AllTrueStates.Length() == 9)//All true states found
                    {
                        StateCheck = AllTrueStates.Get(7).GetMoves();
                    }
                    if (AllTrueStates.Position(StateCheck.Get(i)) != -1)//returning -1 means the safe state has not been found
                    {
                        i++;
                        continue;
                    }
                    if (AllFalseStates.Position(StateCheck.Get(i)) != -1)//returning -1 means the safe state has not been found
                    {
                        i++;
                        continue;
                    }
                    if (StateCheck.Get(i).IsSafe() == true)//Add safe state to stack
                    {
                        stateStack.Pop();
                        Console.WriteLine(StateCheck.Get(i).ToString());
                        stateStack.Push(StateCheck.Get(i));
                        LatestState = StateCheck.Get(i);
                        AllTrueStates.Add(LatestState);
                        //StateCheck = LatestState.GetMoves();
                    }
                    else
                    {
                        stateStack.Pop();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(StateCheck.Get(i) + " ---> unsafe");//print out unsafe state on console
                        stateStack.Push(StateCheck.Get(i));
                        AllFalseStates.Add(StateCheck.Get(i));
                        Console.ResetColor();
                    }
                    i++;
                    
                }
                StateCheck = LatestState.GetMoves();
                i = 0;
                if (LatestState.IsFinal())//Checks to see if the problem has been solved 
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Problem solved final state found: " + LatestState.ToString());
                    Console.ResetColor();
                    break;
                }
            }
            // TODO...
        } // StackSolution

        static void Main (string[] args)
        {
            Console.WriteLine("Queue Solution:");
            QueueSolution();

            Console.WriteLine("\nStack Solution:");
            StackSolution();
            Console.ReadLine();
        } // Main
    } // class Program
}
