﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Threading;

namespace Hanoi
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static int numMoves;//keeps the number of moves made by MoveDisks() function
        public MainWindow()
        {
            InitializeComponent();

            if (IsLoaded == true)
                Environment.Exit(0);

        }
        /// <summary>
        /// manages some of the UI elements (enables or disables)
        /// </summary>
        /// <param name="State">State in which the elemets should be</param>
        private void Manage_Components(bool State)
        {
            btnStart.IsEnabled = State;
            txtNum_Disks.IsEnabled = State;
        }

        /// <summary>
        /// Creates 3 Towers and inserts the amount disks the user has specified into the source tower
        /// </summary>
        /// <param name="Total_Disks">TTotal amount of disks that will be used</param>
        void CreateTowers(int Total_Disks)
        {
            //clears all canvas in the GUI and makes sure user cant click start button after process has already started
            Manage_Components(false);
            playground_A.Children.Clear();
            playground_B.Children.Clear();
            playground_C.Children.Clear();
            //creates towers
            Tower A = new Tower('A',ref playground_A,Total_Disks);
            Tower B = new Tower('B', ref playground_B,Total_Disks);
            Tower C = new Tower('C', ref playground_C, Total_Disks);
            //inserts disks into what will be used as the source tower
            for (int i = Total_Disks; i >0; i--)  A.Add(i);
            //Times how long it takes to move disks from the source to destination tower
            Stopwatch sw = Stopwatch.StartNew();
            MoveDisks(Total_Disks, ref A, ref C, ref B);
            sw.Stop();
            MessageBox.Show(string.Format("Time taken: {0}ms.\n Moves needed: {1}", sw.ElapsedMilliseconds,numMoves));
            Manage_Components(true);
        }

        /// <summary>
        /// Recursive function that moves disks from source tower into the destination tower
        /// </summary>
        /// <param name="numDisk">The number of disks in the current iteration of the function</param>
        /// <param name="source">The source tower from where disks need to be moved from</param>
        /// <param name="destination">The destination tower where the disks need to be moved to</param>
        /// <param name="temp">The temporary tower which will be used to asisst the moving the disks from the source to the destination tower</param>
        void MoveDisks(int numDisk,ref Tower source, ref Tower destination, ref Tower temp)
        {
            //PRE: numDisk>0
            //POST: MoveDisk() should be called again until case is reached
            if (numDisk == 1)//base case
            {
                numMoves++;
                destination.Add(source.Remove());
            }
            else
            {
                MoveDisks(numDisk - 1, ref source, ref temp,ref destination );
                numMoves++;
                destination.Add(source.Remove());
                MoveDisks(numDisk - 1, ref temp, ref destination, ref source);
            }
        }

        private void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            CreateTowers(Convert.ToInt16(txtNum_Disks.Text));//makes towers based on the amount specified 
        }
        /// <summary>
        /// Displays number of moves needed depending on the amount of disks
        /// </summary>
        private void TxtNum_Disks_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (int.TryParse(txtNum_Disks.Text, out int n) && n > 0)//checks if user entered value is valid
            {
                btnStart.IsEnabled = true;
                txtMoves.Text = Convert.ToString(Math.Pow(2, n) - 1);//formula for calculating amount of moves needed
            }
            else{
                txtMoves.Text = "";
                btnStart.IsEnabled = false;
            }
        }
    }
}
