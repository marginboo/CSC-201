﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.IO;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Threading;
using System.Windows.Threading;


namespace Hanoi
{
    /// <summary>
    /// A class used to represent a single tower of Hanoi
    /// </summary>
    class Tower
    {
        private const int maxDisks = 64;//Total amount disks in a tower of Hanoi
        /// <summary>
        /// array used to represent the amount disks in a tower
        /// </summary>
        private int[] disks = new int[maxDisks];
        /// <summary>
        /// Currrent amount of disks stored in the tower
        /// </summary>
        private int numDisks;
        public char ID { get; private set; }
        /// <summary>
        /// The canvas utalized by the tower
        /// </summary>
        private Canvas canvas { get; set; }
        /// <summary>
        /// List used to hold the image objects
        /// </summary>
        private List<Image> Images_Of_Disks = new List<Image>();
        /// <summary>
        /// Total amount of disks
        /// </summary>
        private  double Total_disks { get;set;}
        /// <summary>
        /// A list that stores the previous y positions of disk images on the canvas
        /// </summary>
        private List<double> prevDiskImagePos = new List<double>();
        /// <summary>
        /// The current y position of the disk image on the canvas
        /// </summary>
        private double diskImagePos;
        /// <summary>
        /// Constructor for a tower of Hanoi 
        /// </summary>
        /// <param name="ID">Used to identify current tower</param>
        /// <param name="canvas">individual canvas used to keep track of the towers state</param>
        /// <param name="Total_disks">Used to identify current tower</param>
        public Tower(char ID,ref Canvas canvas,int Total_disks){
            this.ID = ID;
            this.Total_disks = Total_disks;
            this.canvas = canvas;
            numDisks = 0;
            Canvas.SetTop(canvas, canvas.ActualHeight);
            Canvas.SetBottom(canvas, 5);
            diskImagePos = Canvas.GetBottom(canvas);
        }
        /// <summary>
        /// Increases the number of disks in tower and takes a disk from the parameters and adds it into an int array
        /// </summary>
        /// <param name="disk">The size of the disk that is being inserted into the tower</param>
        public void Add(int disk)
        {
            //PRE:disk>0
            //POST:numDisk should increase by 1
            if (disk > maxDisks)
            {
                throw new ArgumentException("You cannot add more disks than the max capacity of a tower\n");
            }
            else if (numDisks >= 0)
            {
                if (numDisks != 0 && disks[numDisks - 1] < disk)
                {
                    throw new ArgumentException(string.Format("You cannot add a bigger disk {1} ontop of a smaller disk {0}\nDisk size {2} object {3}", disks[numDisks - 1], disk, numDisks, ID));
                }
                disks[numDisks] = disk;
                //creates new process in order to display the current state of a tower in the UI 
                //Adds a disk (from top-to-bottom) to current tower
                Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, new ThreadStart(delegate {
                    System.Threading.Thread.Sleep(400);
                    Image diskImage = new Image();
                    diskImage.Source = new BitmapImage(new Uri("pack://application:,,,/Hanoi;component/Images/disk.png"));
                    diskImage.Width = (canvas.Width)*disks[numDisks]/ Total_disks;
                    Images_Of_Disks.Add(diskImage);
                    prevDiskImagePos.Add(diskImagePos);
                    canvas.Children.Add(diskImage);
                    Canvas.SetRight(diskImage, canvas.Width / 2 - (diskImage.Width / 2));           
                    Canvas.SetBottom(diskImage, diskImagePos);
                    diskImagePos += diskImage.Width/disk;  
                }));
                numDisks++;
            }
        }
        /// <summary>
        /// Removes the top-most disk from the tower and its components
        /// </summary>
        /// <returns>Returns value of the disk that was removed</returns>
        public int Remove()
        {
            //PRE:NumDiks>0
            //POST: Returns the top-most disk
            if (numDisks > 0)//Tower cannot remove a disk if its empty
            {
                int TopDisk = disks[--numDisks];
                disks[numDisks] = 0;
                diskImagePos = prevDiskImagePos[numDisks];//returns pervious y position of disk on the canvas
                prevDiskImagePos.RemoveAt(numDisks);//removes pervious disk y position 
                //creates new process in order to display the current state of a tower in the UI 
                //removes the top-most disk from current tower in the UI
                Application.Current.Dispatcher.Invoke(DispatcherPriority.Background, new ThreadStart(delegate { 
                    canvas.Children.Remove(Images_Of_Disks[numDisks]);
                    Images_Of_Disks.Remove(Images_Of_Disks[numDisks]);
                    System.Threading.Thread.Sleep(400);
                }));

                return TopDisk;
            }
            else throw new ArgumentException("Cannot remove a disk from an empty tower");
        }
    }
}
