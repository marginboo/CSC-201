﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hanoi
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Tower A = new Tower('A');
        Tower B = new Tower('B');
        Tower C = new Tower('C');
        int num = 3;
        int counter = 0;
        public MainWindow()
        {
            InitializeComponent();
            for (int i = num; i > 0; i--)
            {
                A.Add(i);
            }
            Stopwatch sw = new Stopwatch();
            sw.Start();
            Recursion(num, A, B, C);
            sw.Stop();
            int moves = counter;
            txtbox.Text += "Took " + sw.ElapsedMilliseconds.ToString() + "ms" + "\r\n";
            txtbox.Text += "Took " + moves.ToString() + " moves";
        }
        
        public void Recursion(int num, Tower A, Tower B, Tower C)
        {
            if (num == 1)
            {
                counter++;
                txtbox.Text += "Moved " + num.ToString() + " from " + A.ID.ToString() + " to " + C.ID.ToString() + "\r\n";
                int number = A.Remove();
                C.Add(number);
            }
            else
            {
                counter++;
                Recursion(num - 1, A, C, B);
                txtbox.Text += "Moved " + num.ToString() + " from " + A.ID.ToString() + " to " + C.ID.ToString() + "\r\n";
                int number = A.Remove();
                C.Add(number);
                Recursion(num - 1, B, A, C);
            }
        }

        public class Tower
        {
            int[] disks = new int[64];
            private int NumDisks { get; set; }
            
            public char ID { get; private set; }

            // Removes a disk 
            public int Remove()
            {
                if (NumDisks > 0)
                {
                    int temp = disks[NumDisks - 1];
                    NumDisks--;
                    return temp;
                }
                else
                {
                    throw new ArgumentException("cannot remove disks");
                }
            }

            // Adds a disk to a tower
            public void Add(int disk)
            {
                // checks to see if there is a disk in the tower
                if(NumDisks > 0)
                {
                    if (disks[NumDisks -1] > disk)
                    {
                        disks[NumDisks] = disk;
                        NumDisks++;
                    }
                    else
                    {
                        throw new ArgumentException("Cannot add number bigger on a smaller number");
                    }
                }
                else
                {
                    disks[NumDisks] = disk;
                    NumDisks++;
                }
            }

            //Constructor for the tower
            public Tower(char ID)
            {
                this.ID = ID;
                NumDisks = 0;
            }
        }
    }
}
