﻿using System;
using cs2;

namespace FamersProblem
{
    class Program
    {
        /// <summary>
        /// Solution to the Farmer's Problem using a Queue.
        /// </summary>
        static ProblemState Queue = new ProblemState();
        static ProblemState Stack = new ProblemState();
        static GenericList<ProblemState> States;
        private static void QueueSolution ()
        {
            States = Queue.GetMoves();
            int man = 0;
            while (States.Get(man).IsSafe())
            {


                man++;
            }

            //  TODO...
        } // QueueSolution

        /// <summary>
        /// Solution to the Farmer's Problem using a Stack.
        /// </summary>
        private static void StackSolution ( )
        {
            // TODO...
        } // StackSolution

        static void Main (string[] args)
        {
            Console.WriteLine("Queue Solution:");
            QueueSolution();

            Console.WriteLine("\nStack Solution:");
            StackSolution();
        } // Main
    } // class Program
}
